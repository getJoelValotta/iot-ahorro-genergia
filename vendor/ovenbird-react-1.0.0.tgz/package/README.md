# @ovenbird/react

Componentes para leer dispositivos Ovenbird desde Next.js. React 18. El secreto del integrador no entra en este paquete ni en variables `NEXT_PUBLIC_*`: `getToken` llama al backend del grupo.

## Instalación

```bash
npm install ./dist-packages/ovenbird-react-1.0.0.tgz
```

Los estilos se inyectan al montar `OvenbirdProvider` (clases `ob-` y variables CSS, incluido modo oscuro). También se puede enlazar `style.css`.

## Ejemplo

```tsx
'use client';
import { DeviceMap, OvenbirdProvider } from '@ovenbird/react';

<OvenbirdProvider
  baseUrl={process.env.NEXT_PUBLIC_OVENBIRD_URL!}
  getToken={async () => (await fetch('/api/ovenbird/embed-token')).json().then((body) => body.token)}
>
  <DeviceMap deviceIds={ids} showTrail trailMinutes={30} height={420} />
</OvenbirdProvider>
```

Leaflet se importa dentro de un efecto, en el navegador. El mapa usa teselas de OpenStreetMap con atribución y omite ubicaciones ausentes o con `fix = none`.

`useDeviceStatus` abre el SSE de `/v1/embed/stream`. Si el token responde 401, el provider pide otro.
