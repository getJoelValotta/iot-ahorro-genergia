# @ovenbird/node

Cliente de Ovenbird Cloud para el backend de cada grupo. Node 20+, ESM y CJS, `fetch` nativo.

## Instalación

Dentro de este monorepo el paquete ya está enlazado. Para entregarlo sin publicar en npm:

```bash
npm run pack:sdks
npm install ./dist-packages/ovenbird-node-1.0.0.tgz
```

## Ejemplo

```ts
import { OvenbirdClient } from '@ovenbird/node';

const ob = new OvenbirdClient({
  baseUrl: process.env.OVENBIRD_URL!,
  clientId: process.env.OVENBIRD_CLIENT_ID!,
  clientSecret: process.env.OVENBIRD_CLIENT_SECRET!,
});

const page = await ob.devices.list();
```

En NestJS: `OvenbirdModule.forRoot({ baseUrl, clientId, clientSecret })` y se inyecta `OvenbirdService`. También existe `forRootAsync`.

El client secret no va en el frontend. El backend pide el token de embebido con `ob.embed.createToken` y se lo entrega a su propia UI.

## Errores

| Clase | Cuándo |
|---|---|
| `OvenbirdError` | Cualquier falla. Tiene `status`, `code`, `message` y `details`. |
| `OvenbirdAuthError` | 401. |
| `OvenbirdNotFoundError` | 404. |
| `OvenbirdValidationError` | 422, o un DP que no cumple el producto. |
| `OvenbirdRateLimitError` | 429. Incluye `retryAfterMs`. |

Un 401 renueva el access token una sola vez y reintenta. Los 5xx, 429 y los errores de red se reintentan (`retries`, por defecto 2) con espera y jitter. Un 429 respeta `Retry-After`. Un 4xx no se reintenta.

`events.subscribe` reconecta el SSE y reenvía `Last-Event-ID`. `commands.waitForAck` rechaza si el comando falla, vence o se agota la espera.
