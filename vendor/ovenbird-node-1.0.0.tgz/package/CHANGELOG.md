# Changelog

## 1.0.0

Primera superficie pública: dispositivos, emparejamiento, comandos, eventos SSE y tokens de embebido, más el módulo NestJS.
